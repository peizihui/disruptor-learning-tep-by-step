package com.bfxy.disruptor.ability;

public interface Constants {

	int EVENT_NUM_OHM = 100000000;
	
	int EVENT_NUM_FM = 50000000;
	
	int EVENT_NUM_OM = 10000000;
	
}
